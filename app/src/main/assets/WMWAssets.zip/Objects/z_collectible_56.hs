<?xml version="1.0"?>
<InteractiveObject>
  <Shapes>
    <Shape>
      <Point pos="-1.887500 3.362500"/>
      <Point pos="2.650000 3.050000"/>
      <Point pos="1.812500 -3.675001"/>
      <Point pos="-2.737500 -3.087501"/>
    </Shape>
  </Shapes>
  <Sprites>
    <Sprite filename="/Sprites/collectible_starburst.sprite" pos="0 0" angle="0" gridSize="12 -12" isBackground="true"/>
    <Sprite filename="/Sprites/z_collectible_56.sprite" pos="0 0" angle="0" gridSize="8 -8" isBackground="true"/>
  </Sprites>
  <DefaultProperties>
    <Property name="CollectibleID" value="56"/>
    <Property name="Type" value="collectible"/>
  </DefaultProperties>
</InteractiveObject>

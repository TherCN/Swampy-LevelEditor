<?xml version="1.0"?>
<InteractiveObject>
  <Shapes>
    <Shape>
      <Point pos="0.445312 -1.978127"/>
      <Point pos="-0.329688 -3.629686"/>
      <Point pos="-2.548439 -3.368750"/>
      <Point pos="-3.285939 -2.134374"/>
      <Point pos="-2.815625 -0.454688"/>
      <Point pos="-0.817187 -0.092186"/>
      <Point pos="2.107812 3.504687"/>
      <Point pos="3.026565 2.906251"/>
      <Point pos="0.059375 -0.814064"/>
    </Shape>
  </Shapes>
  <Sprites>
    <Sprite filename="/Sprites/collectible_starburst.sprite" pos="0 0" angle="0" gridSize="12 -12" isBackground="true"/>
    <Sprite filename="/Sprites/music_collect_12.sprite" pos="0 0" angle="0" gridSize="8 -8" isBackground="true"/>
  </Sprites>
  <DefaultProperties>
    <Property name="AllieMode" value="1"/>
    <Property name="CollectibleID" value="12"/>
    <Property name="Type" value="collectible"/>
  </DefaultProperties>
</InteractiveObject>

<?xml version="1.0"?>
<InteractiveObject>
	<Shapes>
		<Shape>
			<Point pos="-3.752 -2.789" />
			<Point pos="-3.752 -0.039" />
			<Point pos="-1.432 -0.039" />
			<Point pos="-1.432  2.815" />
            <Point pos=" 1.376  2.815" />            
            <Point pos=" 1.376 -0.039" />
            <Point pos=" 3.838 -0.039" />
            <Point pos=" 3.838 -2.789" />
		</Shape>
	</Shapes>
	<Sprites>
		<Sprite filename="/Sprites/pipe_t_joint.sprite" pos="0 0" angle="0" gridSize="8.625 -6.5" />
    </Sprites>
	<DefaultProperties>
	</DefaultProperties>
</InteractiveObject>

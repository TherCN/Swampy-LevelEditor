<?xml version="1.0"?>
<InteractiveObject>
  <Shapes>
    <Shape>
      <Point pos="2.101562 -1.610940"/>
      <Point pos="0.920312 -2.449999"/>
      <Point pos="-0.064064 -3.540625"/>
      <Point pos="-3.864064 -0.259374"/>
      <Point pos="-2.682812 1.451563"/>
      <Point pos="-0.715625 3.087501"/>
      <Point pos="1.529688 3.496874"/>
      <Point pos="3.784377 2.906251"/>
      <Point pos="3.746875 -1.548439"/>
    </Shape>
  </Shapes>
  <Sprites>
    <Sprite filename="/Sprites/collectible_starburst.sprite" pos="0 0" angle="0" gridSize="12 -12" isBackground="true"/>
    <Sprite filename="/Sprites/music_collect_13.sprite" pos="0 0" angle="0" gridSize="8 -8" isBackground="true"/>
  </Sprites>
  <DefaultProperties>
    <Property name="AllieMode" value="1"/>
    <Property name="CollectibleID" value="13"/>
    <Property name="Type" value="collectible"/>
  </DefaultProperties>
</InteractiveObject>

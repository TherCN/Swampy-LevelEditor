<?xml version="1.0"?>
<InteractiveObject>
	<Sprites>
		<Sprite filename="/Sprites/jagged_overlay.sprite" pos="0 0" angle="0" gridSize="6 -6" />
	</Sprites>
</InteractiveObject>


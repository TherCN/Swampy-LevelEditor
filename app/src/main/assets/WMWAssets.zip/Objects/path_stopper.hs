<?xml version="1.0"?>
<InteractiveObject>
	<Sprites>
		<Sprite filename="/Sprites/track_stopper.sprite" pos="0 0" angle="0" gridSize="7.5 -3.75" isBackground="true" />
	</Sprites>
</InteractiveObject>


<?xml version="1.0"?>
<InteractiveObject>
	<Shapes>
		<Shape>
			<Point pos="0 2.75" />
			<Point pos="3.02 2.02" />
			<Point pos="3.75 0" />
			<Point pos="3.02 -2.02" />
			<Point pos="0 -2.75" />
			<Point pos="-3.02 -2.02" />
			<Point pos="-3.75 0" />
			<Point pos="-3.02 2.02" />
		</Shape>
	</Shapes>
	<Sprites>
		<Sprite filename="/Sprites/cranky_food_x_28.sprite" pos="0 0" angle="0" gridSize="6 -6" isBackground="true" />
	</Sprites>
	<DefaultProperties>
		<Property name="Type" value="algaehider" />
		<Property name="AlgaeCount" value="20" />
		<Property name="IgnoreInEditorObjectSelect" value="1" />
	</DefaultProperties>
</InteractiveObject>

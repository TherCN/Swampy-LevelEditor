<?xml version="1.0"?>
<InteractiveObject>
  <Shapes>
    <Shape>
      <Point pos="3.418748 -0.507812"/>
      <Point pos="1.257812 -3.821877"/>
      <Point pos="-0.650001 -3.442186"/>
      <Point pos="-1.079689 -2.876563"/>
      <Point pos="-2.176564 -2.907811"/>
      <Point pos="-3.729687 0.576563"/>
      <Point pos="-3.684375 3.071876"/>
      <Point pos="-0.525000 3.723437"/>
      <Point pos="0.307815 3.085938"/>
      <Point pos="3.114063 2.404686"/>
      <Point pos="3.726563 1.157812"/>
    </Shape>
  </Shapes>
  <Sprites>
    <Sprite filename="/Sprites/collectible_starburst.sprite" pos="0 0" angle="0" gridSize="12 -12" isBackground="true"/>
    <Sprite filename="/Sprites/music_collect_22.sprite" pos="0 0" angle="0" gridSize="8 -8" isBackground="true"/>
  </Sprites>
  <DefaultProperties>
    <Property name="AllieMode" value="1"/>
    <Property name="CollectibleID" value="22"/>
    <Property name="Type" value="collectible"/>
  </DefaultProperties>
</InteractiveObject>

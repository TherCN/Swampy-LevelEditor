<?xml version="1.0"?>
<InteractiveObject>
  <Shapes>
    <Shape>
      <Point pos="3.075000 3.275001"/>
      <Point pos="0.874999 -0.462500"/>
      <Point pos="-2.787500 -2.825001"/>
      <Point pos="-0.906250 1.162500"/>
    </Shape>
  </Shapes>
  <Sprites>
    <Sprite filename="/Sprites/collectible_starburst.sprite" pos="0 0" angle="0" gridSize="12 -12" isBackground="true"/>
    <Sprite filename="/Sprites/z_collectible_61.sprite" pos="0 0" angle="0" gridSize="8 -8" isBackground="true"/>
  </Sprites>
  <DefaultProperties>
    <Property name="CollectibleID" value="4"/>
    <Property name="Type" value="collectible"/>
  </DefaultProperties>
</InteractiveObject>

<?xml version="1.0"?>
<InteractiveObject>
  <Shapes>
    <Shape>
      <Point pos="-1.700001 -0.612500"/>
      <Point pos="-2.900001 1.062500"/>
      <Point pos="-1.412500 3.450000"/>
      <Point pos="0.087500 3.737500"/>
      <Point pos="0.624999 2.037501"/>
      <Point pos="-0.724999 -0.312500"/>
      <Point pos="1.706249 -0.925001"/>
      <Point pos="2.809376 -2.018750"/>
      <Point pos="2.348437 -3.465625"/>
      <Point pos="-0.137500 -3.337501"/>
      <Point pos="-1.912500 -2.150000"/>
    </Shape>
  </Shapes>
  <Sprites>
    <Sprite filename="/Sprites/collectible_starburst.sprite" pos="0 0" angle="0" gridSize="12 -12" isBackground="true"/>
    <Sprite filename="/Sprites/z_collectible_58.sprite" pos="0 0" angle="0" gridSize="8 -8" isBackground="true"/>
  </Sprites>
  <DefaultProperties>
    <Property name="CollectibleID" value="58"/>
    <Property name="Type" value="collectible"/>
  </DefaultProperties>
</InteractiveObject>

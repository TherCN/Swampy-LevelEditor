<?xml version="1.0"?>
<InteractiveObject>
	<!-- basic pipe section (straight - short) -->
	<Shapes>
		<Shape>
			<Point pos="-2 1" />
			<Point pos="2 1" />
			<Point pos="2 -1" />
			<Point pos="-2 -1" />
		</Shape>
	</Shapes>
	<Sprites>
		<Sprite filename="/Sprites/pipe_straight_short.sprite" pos="0 0" angle="0" gridSize="4 -2" />
	</Sprites>
	<DefaultProperties>
	</DefaultProperties>
</InteractiveObject>

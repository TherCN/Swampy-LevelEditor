<?xml version="1.0"?>
<InteractiveObject>
  <Shapes>
    <Shape>
      <Point pos="-1.587501 -0.200000"/>
      <Point pos="-2.637500 -0.250000"/>
      <Point pos="-1.975001 1.500001"/>
      <Point pos="-0.587501 2.450001"/>
      <Point pos="1.212500 2.349999"/>
      <Point pos="0.693751 1.387500"/>
      <Point pos="1.862500 -0.962501"/>
      <Point pos="3.287500 -2.000000"/>
      <Point pos="0.462500 -3.750000"/>
      <Point pos="0.112500 -2.150000"/>
    </Shape>
  </Shapes>
  <Sprites>
    <Sprite filename="/Sprites/collectible_starburst.sprite" pos="0 0" angle="0" gridSize="12 -12" isBackground="true"/>
    <Sprite filename="/Sprites/z_collectible_59.sprite" pos="0 0" angle="0" gridSize="8 -8" isBackground="true"/>
  </Sprites>
  <DefaultProperties>
    <Property name="CollectibleID" value="59"/>
    <Property name="Type" value="collectible"/>
  </DefaultProperties>
</InteractiveObject>

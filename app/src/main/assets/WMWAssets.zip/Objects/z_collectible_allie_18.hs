<?xml version="1.0"?>
<InteractiveObject>
  <Shapes>
    <Shape>
      <Point pos="-2.918751 -3.868749"/>
      <Point pos="-3.825000 -2.849999"/>
      <Point pos="3.053125 3.887499"/>
      <Point pos="3.737502 3.281251"/>
    </Shape>
  </Shapes>
  <Sprites>
    <Sprite filename="/Sprites/collectible_starburst.sprite" pos="0 0" angle="0" gridSize="12 -12" isBackground="true"/>
    <Sprite filename="/Sprites/music_collect_18.sprite" pos="0 0" angle="0" gridSize="8 -8" isBackground="true"/>
  </Sprites>
  <DefaultProperties>
    <Property name="AllieMode" value="1"/>
    <Property name="CollectibleID" value="18"/>
    <Property name="Type" value="collectible"/>
  </DefaultProperties>
</InteractiveObject>

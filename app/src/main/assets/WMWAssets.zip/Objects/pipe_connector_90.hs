<?xml version="1.0"?>
<InteractiveObject>
	<!-- basic pipe connector section (90 degree elbow) -->
	<Shapes>
		<Shape>
			<Point pos="-3.5 3.5" />
			<Point pos="0.5 3.5" />
			<Point pos="0.5 1.5" />
			<Point pos="1.5 0.5" />
			<Point pos="3.5 0.5" />
			<Point pos="3.5 -3.5" />
			<Point pos="0.5 -3.5" />
			<Point pos="-3.5 0.5" />
		</Shape>
	</Shapes>
	<Sprites>
		<Sprite filename="/Sprites/pipe_connector_90.sprite" pos="0 0" angle="0" gridSize="7 -7" />
	</Sprites>
	<DefaultProperties>
	</DefaultProperties>
</InteractiveObject>

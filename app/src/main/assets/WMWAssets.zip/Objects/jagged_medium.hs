<?xml version="1.0"?>
<InteractiveObject>
	<Shapes>
		<Shape>
			<Point pos="-4.0 4" />
			<Point pos="-3.5 4.5" />
			<Point pos="1.0 6" />
			<Point pos="2.5 3.5" />
			<Point pos="3.0 1.0" />
			<Point pos="2.5 -1.5" />
		</Shape>
	</Shapes>
	<Sprites>
		<Sprite filename="/Sprites/jagged_medium.sprite" pos="0 2.75" angle="0" gridSize="10.0 -10" isBackground="true" />
	</Sprites>
	<DefaultProperties>
		<Property name="PopsBalloons" value="1" />
		<Property name="FluidsCollide" value="0" />
	</DefaultProperties>
</InteractiveObject>

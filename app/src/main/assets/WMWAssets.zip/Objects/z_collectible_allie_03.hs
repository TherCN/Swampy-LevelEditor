<?xml version="1.0"?>
<InteractiveObject>
  <Shapes>
    <Shape>
      <Point pos="2.028123 -0.593750"/>
      <Point pos="-0.353126 -3.259375"/>
      <Point pos="-1.934376 -3.806249"/>
      <Point pos="-3.128125 -2.478125"/>
      <Point pos="-2.418750 -0.506249"/>
      <Point pos="0.225000 2.231249"/>
      <Point pos="0.487502 3.703126"/>
      <Point pos="2.028125 3.584374"/>
      <Point pos="3.081252 2.175000"/>
      <Point pos="3.003125 0.928125"/>
      <Point pos="1.218751 0.556250"/>
    </Shape>
  </Shapes>
  <Sprites>
    <Sprite filename="/Sprites/collectible_starburst.sprite" pos="0 0" angle="0" gridSize="12 -12" isBackground="true"/>
    <Sprite filename="/Sprites/music_collect_03.sprite" pos="0 0" angle="0" gridSize="8 -8" isBackground="true"/>
  </Sprites>
  <DefaultProperties>
    <Property name="AllieMode" value="1"/>
    <Property name="CollectibleID" value="3"/>
    <Property name="Type" value="collectible"/>
  </DefaultProperties>
</InteractiveObject>

<?xml version="1.0"?>
<InteractiveObject>
  <Shapes>
    <Shape>
      <Point pos="2.934373 -2.953125"/>
      <Point pos="-0.125000 -3.790627"/>
      <Point pos="-0.118751 -2.934374"/>
      <Point pos="-1.728126 -2.446875"/>
      <Point pos="-3.231251 -2.681249"/>
      <Point pos="-3.393750 0.365625"/>
      <Point pos="-2.481250 0.900001"/>
      <Point pos="-2.681250 2.824999"/>
      <Point pos="1.253127 3.843751"/>
      <Point pos="3.153125 3.287499"/>
    </Shape>
  </Shapes>
  <Sprites>
    <Sprite filename="/Sprites/collectible_starburst.sprite" pos="0 0" angle="0" gridSize="12 -12" isBackground="true"/>
    <Sprite filename="/Sprites/music_collect_08.sprite" pos="0 0" angle="0" gridSize="8 -8" isBackground="true"/>
  </Sprites>
  <DefaultProperties>
    <Property name="AllieMode" value="1"/>
    <Property name="CollectibleID" value="8"/>
    <Property name="Type" value="collectible"/>
  </DefaultProperties>
</InteractiveObject>

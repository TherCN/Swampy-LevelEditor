<?xml version="1.0"?>
<InteractiveObject>
	<!-- basic pipe section (elbow) -->
	<Shapes>
		<Shape>
			<Point pos="-2 2" />
			<Point pos="2 2" />
			<Point pos="2 -2" />
			<Point pos="0 -2" />
			<Point pos="0 0" />
			<Point pos="-2 0" />
		</Shape>
	</Shapes>
	<Sprites>
		<Sprite filename="/Sprites/pipe_elbow_2_m.sprite" pos="0.05 0.05" angle="0" gridSize="3.65 -3.65" />
	</Sprites>
	<DefaultProperties>
	</DefaultProperties>
</InteractiveObject>

<?xml version="1.0"?>
<InteractiveObject>
	<Sprites>
		<Sprite filename="/Sprites/track_elbow_4.sprite" pos="0 0" angle="0" gridSize="10.15 -10.15" isBackground="true" />
	</Sprites>
</InteractiveObject>


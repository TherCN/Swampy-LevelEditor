<?xml version="1.0"?>
<InteractiveObject>
  <Shapes>
    <Shape>
      <Point pos="2.199998 -0.500000"/>
      <Point pos="1.750000 -2.275002"/>
      <Point pos="0.537499 -1.199999"/>
      <Point pos="0.162499 -2.900000"/>
      <Point pos="-2.200001 -3.712499"/>
      <Point pos="-0.643750 0.193750"/>
      <Point pos="-0.887500 2.900001"/>
      <Point pos="1.662500 3.887499"/>
      <Point pos="2.268752 2.812501"/>
      <Point pos="1.637500 1.849999"/>
      <Point pos="-0.012498 1.112500"/>
      <Point pos="0.237500 0.412500"/>
      <Point pos="1.500001 0.587500"/>
    </Shape>
  </Shapes>
  <Sprites>
    <Sprite filename="/Sprites/collectible_starburst.sprite" pos="0 0" angle="0" gridSize="12 -12" isBackground="true"/>
    <Sprite filename="/Sprites/z_collectible_62.sprite" pos="0 0" angle="0" gridSize="8 -8" isBackground="true"/>
  </Sprites>
  <DefaultProperties>
    <Property name="CollectibleID" value="5"/>
    <Property name="Type" value="collectible"/>
  </DefaultProperties>
</InteractiveObject>

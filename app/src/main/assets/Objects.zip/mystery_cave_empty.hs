<?xml version="1.0"?>
<InteractiveObject>
	<Shapes>
		<Shape>
			<Point pos="-2.0  2.0" />
			<Point pos=" 2.0  2.0" />
			<Point pos=" 2.0 -2.0" />
			<Point pos="-2.0 -2.0" />
		</Shape>
	</Shapes>
	<Sprites>   
	</Sprites>
	<DefaultProperties>
		<Property name="Type" value="mysterycave" />
		<Property name="PlatinumType" value="platinum" />        
		<Property name="MaterialType" value="-1"/>        
	</DefaultProperties>
</InteractiveObject>

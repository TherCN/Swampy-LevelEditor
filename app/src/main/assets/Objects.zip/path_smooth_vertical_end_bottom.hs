<?xml version="1.0"?>
<InteractiveObject>
	<Sprites>
		<Sprite filename="/Sprites/smooth_track_vertical_end_bottom.sprite" pos="0 0" angle="0" gridSize="6.234 -6" isBackground="true" />
	</Sprites>
</InteractiveObject>


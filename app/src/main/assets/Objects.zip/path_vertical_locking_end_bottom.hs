<?xml version="1.0"?>
<InteractiveObject>
	<Sprites>
		<Sprite filename="/Sprites/track_vertical_end_bottom.sprite" pos="0 0" angle="0" gridSize="6 -6.234" isBackground="true" />
	</Sprites>
</InteractiveObject>


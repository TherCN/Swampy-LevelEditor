<?xml version="1.0"?>
<InteractiveObject>
	<!-- basic pipe section (straight) -->
	<Shapes>
		<Shape>
			<Point pos="-2 1" />
			<Point pos="0.9 1" />
			<Point pos="1.25 0" />
			<Point pos="0.9 -1" />
			<Point pos="-2 -1" />
		</Shape>
	</Shapes>
	<Sprites>
		<Sprite filename="/Sprites/pipe_into_wall_2.sprite" pos="0 0" angle="0" gridSize="4 -3" />
	</Sprites>
	<DefaultProperties>
	</DefaultProperties>
</InteractiveObject>

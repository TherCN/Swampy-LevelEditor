<?xml version="1.0"?>
<InteractiveObject>
	<Shapes>
		<Shape>
			<Point pos="-6.0 -1.0" />
			<Point pos="-6.0 1.0" />
			<Point pos="-3.5 5.0" />
			<Point pos="3.0 4.5" />
			<Point pos="6.0 1.0" />
			<Point pos="6.0 -1.0" />
		</Shape>
	</Shapes>
	<Sprites>
		<Sprite filename="/Sprites/jagged_large.sprite" pos="0 3.5" angle="0" gridSize="-13.75 -9.5" isBackground="true" />
	</Sprites>
	<DefaultProperties>
		<Property name="PopsBalloons" value="1" />
		<Property name="FluidsCollide" value="0" />
	</DefaultProperties>
</InteractiveObject>

<?xml version="1.0"?>
<InteractiveObject>
  <Shapes>
    <Shape>
      <Point pos="-9.335266 2.219653"/>
      <Point pos="-7.033241 3.903176"/>
      <Point pos="6.830027 3.982116"/>
      <Point pos="9.326236 2.056719"/>
      <Point pos="6.795526 0.594654"/>
      <Point pos="-6.997113 0.580927"/>
    </Shape>
  </Shapes>
  <Sprites>
    <Sprite filename="/Sprites/dirtywall_large.sprite" pos="0 0" angle="0" gridSize="19 -6.625"/>
  </Sprites>
  <DefaultProperties>
    <Property name="Type" value="dirtywall"/>
    <Property name="ParticleArea" value="18.7 4.0"/>        
  </DefaultProperties>
</InteractiveObject>

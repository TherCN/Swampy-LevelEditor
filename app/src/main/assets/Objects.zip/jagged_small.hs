<?xml version="1.0"?>
<InteractiveObject>
	<Shapes>
		<Shape>
			<Point pos="-2.0 -1.0" />
			<Point pos="-2.0 2.5" />
			<Point pos="0.0 3" />
			<Point pos="2.0 2.5" />
			<Point pos="2.0 -1.0" />
		</Shape>
	</Shapes>
	<Sprites>
		<Sprite filename="/Sprites/jagged_small.sprite" pos="0 1.75" angle="0" gridSize="6.0 -6.0" isBackground="true" />
	</Sprites>
	<DefaultProperties>
		<Property name="PopsBalloons" value="1" />
		<Property name="FluidsCollide" value="0" />
	</DefaultProperties>
</InteractiveObject>

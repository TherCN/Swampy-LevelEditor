<?xml version="1.0"?>
<InteractiveObject>
	<Sprites>
		<Sprite filename="/Sprites/fan_cable.sprite" pos="0 0" angle="0" gridSize="4.5 -2.1" />
	</Sprites>
</InteractiveObject>

<?xml version="1.0"?>
<InteractiveObject>
  <Shapes>
    <Shape>
      <Point pos="-0.228126 -3.387499"/>
      <Point pos="-2.134376 -3.884375"/>
      <Point pos="-2.950001 -3.306249"/>
      <Point pos="-2.378125 -2.540625"/>
      <Point pos="-2.965625 3.431251"/>
      <Point pos="-1.321875 3.918749"/>
      <Point pos="0.300002 3.234376"/>
      <Point pos="1.371875 1.756249"/>
      <Point pos="2.425002 2.237500"/>
      <Point pos="3.375001 1.540625"/>
    </Shape>
  </Shapes>
  <Sprites>
    <Sprite filename="/Sprites/collectible_starburst.sprite" pos="0 0" angle="0" gridSize="12 -12" isBackground="true"/>
    <Sprite filename="/Sprites/music_collect_11.sprite" pos="0 0" angle="0" gridSize="8 -8" isBackground="true"/>
  </Sprites>
  <DefaultProperties>
    <Property name="AllieMode" value="1"/>
    <Property name="CollectibleID" value="11"/>
    <Property name="Type" value="collectible"/>
  </DefaultProperties>
</InteractiveObject>

<?xml version="1.0"?>
<InteractiveObject>
  <Shapes>
    <Shape>
      <Point pos="-3.762500 -0.612500"/>
      <Point pos="-1.062500 1.400000"/>
      <Point pos="3.050000 2.512500"/>
      <Point pos="3.912500 1.600000"/>
      <Point pos="1.300000 -1.749999"/>
      <Point pos="-0.162501 -1.587499"/>
      <Point pos="-0.849999 -0.675000"/>
      <Point pos="-1.737500 -2.181251"/>
      <Point pos="-3.000000 -2.187500"/>
    </Shape>
  </Shapes>
  <Sprites>
    <Sprite filename="/Sprites/collectible_starburst.sprite" pos="0 0" angle="0" gridSize="12 -12" isBackground="true"/>
    <Sprite filename="/Sprites/z_collectible_57.sprite" pos="0 0" angle="0" gridSize="8 -8" isBackground="true"/>
  </Sprites>
  <DefaultProperties>
    <Property name="CollectibleID" value="57"/>
    <Property name="Type" value="collectible"/>
  </DefaultProperties>
</InteractiveObject>

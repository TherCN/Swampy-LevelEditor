<?xml version="1.0"?>
<InteractiveObject>
  <Shapes>
    <Shape>
      <Point pos="-2.862500 -1.662500"/>
      <Point pos="0.137500 2.525000"/>
      <Point pos="1.962500 1.700000"/>
      <Point pos="2.918750 0.037500"/>
      <Point pos="-1.300000 -3.499999"/>
    </Shape>
  </Shapes>
  <Sprites>
    <Sprite filename="/Sprites/collectible_starburst.sprite" pos="0 0" angle="0" gridSize="12 -12" isBackground="true"/>
    <Sprite filename="/Sprites/cranky_food_x_16.sprite" pos="0 0" angle="0" gridSize="8 -8" isBackground="true"/>
  </Sprites>
  <DefaultProperties>
    <Property name="CollectibleID" value="17"/>
    <Property name="CrankyMode" value="1"/>
    <Property name="Type" value="collectible"/>
  </DefaultProperties>
</InteractiveObject>

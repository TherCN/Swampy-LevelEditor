<?xml version="1.0"?>
<InteractiveObject>
  <Shapes>
    <Shape>
      <Point pos="3.648438 0.998435"/>
      <Point pos="-2.712501 -3.856249"/>
      <Point pos="-3.673439 -3.681250"/>
      <Point pos="-3.785939 -2.587499"/>
      <Point pos="-0.495313 -0.235938"/>
      <Point pos="-1.773438 0.484375"/>
      <Point pos="-2.184375 2.267189"/>
      <Point pos="-1.485937 3.074999"/>
      <Point pos="0.729690 2.812501"/>
      <Point pos="3.293750 3.857811"/>
      <Point pos="3.885940 3.510937"/>
      <Point pos="3.745312 2.584375"/>
      <Point pos="1.562501 0.845312"/>
    </Shape>
  </Shapes>
  <Sprites>
    <Sprite filename="/Sprites/collectible_starburst.sprite" pos="0 0" angle="0" gridSize="12 -12" isBackground="true"/>
    <Sprite filename="/Sprites/music_collect_14.sprite" pos="0 0" angle="0" gridSize="8 -8" isBackground="true"/>
  </Sprites>
  <DefaultProperties>
    <Property name="AllieMode" value="1"/>
    <Property name="CollectibleID" value="14"/>
    <Property name="Type" value="collectible"/>
  </DefaultProperties>
</InteractiveObject>

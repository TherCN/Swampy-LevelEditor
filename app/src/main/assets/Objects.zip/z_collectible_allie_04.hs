<?xml version="1.0"?>
<InteractiveObject>
  <Shapes>
    <Shape>
      <Point pos="3.218750 -1.993752"/>
      <Point pos="1.881249 -3.137499"/>
      <Point pos="-0.103126 -3.696875"/>
      <Point pos="-1.825001 -3.556249"/>
      <Point pos="-3.315625 0.787500"/>
      <Point pos="-0.700000 2.337501"/>
      <Point pos="1.068750 4.028124"/>
      <Point pos="2.487502 3.453126"/>
      <Point pos="1.746875 2.553124"/>
    </Shape>
  </Shapes>
  <Sprites>
    <Sprite filename="/Sprites/collectible_starburst.sprite" pos="0 0" angle="0" gridSize="12 -12" isBackground="true"/>
    <Sprite filename="/Sprites/music_collect_04.sprite" pos="0 0" angle="0" gridSize="8 -8" isBackground="true"/>
  </Sprites>
  <DefaultProperties>
    <Property name="AllieMode" value="1"/>
    <Property name="CollectibleID" value="4"/>
    <Property name="Type" value="collectible"/>
  </DefaultProperties>
</InteractiveObject>

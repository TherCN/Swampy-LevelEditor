<?xml version="1.0"?>
<InteractiveObject>
  <Shapes>
    <Shape>
      <Point pos="-3.235046 1.072757"/>
      <Point pos="-1.946571 2.379922"/>
      <Point pos="1.809082 2.374134"/>
      <Point pos="3.256929 1.090809"/>
      <Point pos="1.833880 -0.351569"/>
      <Point pos="-1.938184 -0.351568"/>
    </Shape>
  </Shapes>
  <Sprites>
    <Sprite filename="/Sprites/dirtywall_small.sprite" pos="0 0" angle="0" gridSize="6.75 -3.75"/>
  </Sprites>
  <DefaultProperties>
    <Property name="Type" value="dirtywall"/>
    <Property name="ParticleArea" value="6.5 2.0"/>
  </DefaultProperties>
</InteractiveObject>

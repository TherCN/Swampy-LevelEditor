<?xml version="1.0"?>
<InteractiveObject>
  <Shapes>
    <Shape>
      <Point pos="-3.409375 -0.587500"/>
      <Point pos="-3.895313 1.439064"/>
      <Point pos="-1.525000 3.364062"/>
      <Point pos="1.581252 3.890626"/>
      <Point pos="3.903125 -3.900001"/>
    </Shape>
  </Shapes>
  <Sprites>
    <Sprite filename="/Sprites/collectible_starburst.sprite" pos="0 0" angle="0" gridSize="12 -12" isBackground="true"/>
    <Sprite filename="/Sprites/music_collect_19.sprite" pos="0 0" angle="0" gridSize="8 -8" isBackground="true"/>
  </Sprites>
  <DefaultProperties>
    <Property name="AllieMode" value="1"/>
    <Property name="CollectibleID" value="19"/>
    <Property name="Type" value="collectible"/>
  </DefaultProperties>
</InteractiveObject>

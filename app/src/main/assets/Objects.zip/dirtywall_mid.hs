<?xml version="1.0"?>
<InteractiveObject>
  <Shapes>
    <Shape>
      <Point pos="-4.185802 0.204424"/>
      <Point pos="-5.690947 1.677468"/>
      <Point pos="-4.148970 3.268621"/>
      <Point pos="4.220706 3.233642"/>
      <Point pos="5.795731 1.564506"/>
      <Point pos="4.172326 0.139917"/>
    </Shape>
  </Shapes>
  <Sprites>
    <Sprite filename="/Sprites/dirtywall_mid.sprite" pos="0 0" angle="0" gridSize="11.75 -5.375"/>
  </Sprites>
  <DefaultProperties>
    <Property name="Type" value="dirtywall"/>
    <Property name="ParticleArea" value="11.4 3.0"/>    
  </DefaultProperties>
</InteractiveObject>

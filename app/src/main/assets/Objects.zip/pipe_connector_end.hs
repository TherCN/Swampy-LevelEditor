<?xml version="1.0"?>
<InteractiveObject>
	<!-- basic pipe connector section (endpoint) -->
	<Shapes>
		<Shape>
			<Point pos="-2 2" />
			<Point pos="2 2" />
			<Point pos="2 -2" />
			<Point pos="-2 -2" />
		</Shape>
	</Shapes>
	<Sprites>
		<Sprite filename="/Sprites/pipe_connector_end.sprite" pos="0 0" angle="0" gridSize="4 -4" />
	</Sprites>
	<DefaultProperties>
	</DefaultProperties>
</InteractiveObject>

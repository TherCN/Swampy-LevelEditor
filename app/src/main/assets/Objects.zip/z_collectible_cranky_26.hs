<?xml version="1.0"?>
<InteractiveObject>
  <Shapes>
    <Shape>
      <Point pos="-2.262500 -2.600001"/>
      <Point pos="-2.787500 0.949999"/>
      <Point pos="-0.956250 1.400000"/>
      <Point pos="0.728125 2.787501"/>
      <Point pos="0.424999 1.249999"/>
      <Point pos="3.096876 0.284376"/>
      <Point pos="2.599999 -2.787501"/>
    </Shape>
  </Shapes>
  <Sprites>
    <Sprite filename="/Sprites/collectible_starburst.sprite" pos="0 0" angle="0" gridSize="12 -12" isBackground="true"/>
    <Sprite filename="/Sprites/cranky_food_x_28.sprite" pos="0 0" angle="0" gridSize="8 -8" isBackground="true"/>
  </Sprites>
  <DefaultProperties>
    <Property name="CollectibleID" value="26"/>
    <Property name="CrankyMode" value="1"/>
    <Property name="Type" value="collectible"/>
  </DefaultProperties>
</InteractiveObject>

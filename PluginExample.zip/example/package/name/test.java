package example.package.name;
public class mainclass {
    public static void entry()
    {
	System.out.println("Pluginl oading completed!");
    }
}

public class MainEntry{
	public static String PluginName="name";
    public static String PluginVersion="0.0.1";
    public static String PluginEntry="entry";
    public static String PackageName="example.package.name";
	public static String PluginMainClass=PackageName + ".mainclass";

	public static void onPluginLoad()
	{
	    //TODO:Write the code to be executed after the plugin is loaded here
	    System.out.println("The plugin has been loaded!");
	}


}
